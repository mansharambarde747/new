
      $(document).ready(function() {
        $(".pro_box").delay(900).fadeIn(800);
        $(".black").delay(1E3).fadeIn(800);
        $(".pro_box2").delay(2500).fadeIn(800);
        $(".pro_box3").delay(3500).fadeIn(800);
        $("#pop_up_new").delay(4E3).fadeIn(800);
        $("#poptxt").delay(4E3).fadeIn(800)
      });